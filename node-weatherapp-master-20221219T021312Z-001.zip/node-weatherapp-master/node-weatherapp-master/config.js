const constants = {
    openWeatherMap: {
        BASE_URL: "https://api.openweathermap.org/data/2.5/weather?q=",
        SECRET_KEY: "3709f89e826c2838310e77a773533f2d"
    }
}

module.exports = constants;